package com.example.capstone

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class signup1 : AppCompatActivity() {

    private lateinit var verificationId: String

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_signup1)

        auth = FirebaseAuth.getInstance()

        val sendCodeButton = findViewById<Button>(R.id.sendcode_btn)
        val confirmButton = findViewById<Button>(R.id.confirm_btn)
        val numberInputText = findViewById<EditText>(R.id.numberinput_text)
        val codeInputText = findViewById<EditText>(R.id.codeinput_text)
        val progressBar = findViewById<ProgressBar>(R.id.progress_bar)


        // Click listener for sending verification code
        sendCodeButton.setOnClickListener {
            val phoneNumber = numberInputText.text.toString().trim()

            if (phoneNumber.isNotEmpty()) {
                // Send verification code
                progressBar.visibility = View.VISIBLE
                sendVerificationCode(phoneNumber)
            } else {
                // Show error if phone number is empty
                showToast("Please enter a valid phone number")
            }
        }

        // Click listener for confirming verification code
        confirmButton.setOnClickListener {
            val code = codeInputText.text.toString().trim()

            if (code.isNotEmpty()) {
                // Verify the entered verification code
                progressBar.visibility = View.VISIBLE
                verifyCode(code)
            } else {
                // Show error if verification code is empty
                showToast("Please enter the verification code")
            }
        }
    }

    // Function to send verification code to the provided phone number
    private fun sendVerificationCode(phoneNumber: String) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
            phoneNumber,
            60,
            TimeUnit.SECONDS,
            this,
            object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    // Automatically handles verification if the SMS code is detected automatically
                    signInWithPhoneAuthCredential(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    // Show error if verification fails
                    showToast("Verification Failed: ${e.message}")
                }

                override fun onCodeSent(verificationId: String, token: PhoneAuthProvider.ForceResendingToken) {
                    super.onCodeSent(verificationId, token)
                    // Save the verification ID
                    this@signup1.verificationId = verificationId
                    // Show message indicating that verification code is sent
                    showToast("Verification code sent")
                }
            }
        )
    }

    // Function to verify the entered verification code
    private fun verifyCode(code: String) {
        // Create PhoneAuthCredential using verification ID and entered code
        val credential = PhoneAuthProvider.getCredential(verificationId, code)
        // Sign in with the provided credential
        signInWithPhoneAuthCredential(credential)
    }

    // Function to sign in with phone authentication credential
    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign-up successful
                    showToast("Sign-up successful")
                    // Proceed to next activity or perform desired action
                } else {
                    // Sign-up failed, show error message
                    showToast("Sign-up failed: ${task.exception?.message}")
                }
            }
    }

    // Function to display toast message
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    }
}
