package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity


class login_signup : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login_signup)

        val loginButton = findViewById<Button>(R.id.loginBtn)
        val signUpButton = findViewById<Button>(R.id.signUpBtn)

        loginButton.setOnClickListener {
            startActivity(Intent(this, login12::class.java))
        }

        signUpButton.setOnClickListener {
            startActivity(Intent(this, signup1::class.java))

        }
    }
}