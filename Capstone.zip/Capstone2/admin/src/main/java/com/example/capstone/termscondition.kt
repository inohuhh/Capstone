package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.capstone.R.id.checkbox

class termscondition : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_termscondition)

        val checkBox = findViewById<CheckBox>(checkbox)
        val confirmButton = findViewById<Button>(R.id.confirm_btn)

        confirmButton.isEnabled = false

        checkBox.setOnCheckedChangeListener { _, isChecked ->
            confirmButton.isEnabled = isChecked
        }

        confirmButton.setOnClickListener {
            startActivity(Intent(this, login_signup::class.java))
        }

    }
}
